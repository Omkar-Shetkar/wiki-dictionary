# Wiki Dictionary

English - English dictionary based on Wiktionary API - https://en.wiktionary.org/api/rest_v1/
